# GitHub 上传与打包文件清单

本项目同时保留可直接安装的插件与可重复构建的源码。上传 GitHub 时，应保留以下文件，不要仅上传 `src/`。

## 插件运行必需

| 路径 | 用途 |
| --- | --- |
| `kimi.plugin.json` | 插件清单、命令与 MCP 入口配置 |
| `mcp/forge-mcp.mjs` | 已打包的 MCP 可执行入口；安装后无需 `node_modules/` |
| `SYSTEM.md` | 插件系统提示词 |
| `skills/` | 技能说明 |
| `commands/` | 插件命令 |
| `locales/` | 界面本地化资源 |

运行环境需提供 Node.js 22 或更新版本。`mcp/forge-mcp.mjs` 虽然由构建生成，但插件直接引用它，因此必须提交。

## GitHub 源码仓库应保留

| 路径 | 用途 |
| --- | --- |
| `src/` | MCP 源码 |
| `package.json`、`pnpm-lock.yaml`、`pnpm-workspace.yaml` | 依赖、锁定版本和补丁配置 |
| `patches/` | Forge Core 必要补丁；构建时需要 |
| `scripts/` | 构建、一致性检查、校验与测试脚本 |
| `tests/` | 自动化测试与测试夹具 |
| `.github/workflows/ci.yml` | GitHub 持续集成 |
| `.gitignore` | 排除本地文件 |
| `LICENSE`、`README.md`、`README_zh.md` | 许可证、安装与使用说明 |
| `docs/` | 使用、验收、设计和发布说明 |

## 不应提交

- `node_modules/`：本地依赖，可通过锁文件重新安装。
- `.idea/`、`.vscode/`：本地编辑器配置。
- 根目录下的 `PhyAgentOS-Kimi-Plugin/`：旧的嵌套 Git 副本，不是插件依赖；保留在本地，避免重复上传。
- `.env`、`.env.*`、私钥文件：本地敏感配置；脱敏后的 `.env.example` 或 `.env.*.example` 可提交。
- 日志、`.tmp/`、`coverage/`、`dist/`：本地运行或打包产物。
- `.git/`：本地 Git 元数据；通过 Git 推送或 `git archive` 打包，无需手动复制。

忽略规则不会清除历史提交。已跟踪的编辑器配置应从 Git 索引移除，本地文件可继续保留。

## 校验与打包

标准校验流程：

```sh
pnpm install --frozen-lockfile
pnpm test
pnpm run build:check
```

如本地依赖已安装，可直接执行仓库脚本进行检查：

```sh
node scripts/build-mcp.mjs --check
node scripts/validate-plugin.mjs
node scripts/run-tests.mjs
```

提交整理结果后，在仓库根目录生成完整源码包：

```sh
mkdir -p dist
git archive --format=zip --prefix=PhyAgentOS-Kimi-Plugin/ --output=dist/phyagentos-kimi-plugin-source.zip HEAD
```

`git archive` 仅包含指定提交中已跟踪的文件，不会带入本地依赖、嵌套副本或 Git 元数据。压缩包生成后仍需通过 Git 推送分支，或在 GitHub 发布时手动上传；本地打包本身不会上传任何内容。
